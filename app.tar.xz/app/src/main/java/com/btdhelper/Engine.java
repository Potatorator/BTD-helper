package com.btdhelper;

import com.btdhelper.vision.Frame;
import com.btdhelper.vision.Vision;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The automation (PC: run_loop / check_retry / check_shop in auto_retry.py).
 *  - Auto Retry: finds the blue Retry button, taps it (held for whole 60 FPS frames),
 *    checks it disappeared, taps again longer if not, and switches to the longer tap
 *    if quick taps keep missing.
 *  - Shop check every N minutes / on start / on demand: opens SPAWNERS, scans the cards
 *    (quick scan = bottom rows only, or every page), buys wanted rarities whose Buy button
 *    is steady, never more than the limit, stops on a Robux popup, closes the shop.
 */
public final class Engine {
    private final Config cfg;
    private final Device dev;

    private final AtomicBoolean stopReq = new AtomicBoolean(false);
    private final AtomicBoolean shopNowReq = new AtomicBoolean(false);
    private volatile Thread thread;

    // ---- stats & status (read by the panel)
    public volatile int retries, buys, shopChecks;
    public volatile long nextShopAt;     // 0 = none
    public volatile String status = "Stopped";
    private volatile boolean stopping;
    private int fastFails = 0;

    public Engine(Config cfg, Device dev) {
        this.cfg = cfg;
        this.dev = dev;
    }

    // ================================================================ control
    public synchronized boolean isRunning() { return thread != null && thread.isAlive(); }
    public boolean isStopping() { return stopping && isRunning(); }

    public synchronized void start() {
        if (isRunning()) return;
        stopReq.set(false);
        shopNowReq.set(false);
        stopping = false;
        thread = new Thread(this::runLoop, "btd-engine");
        thread.start();
    }

    public void stop() {
        if (!isRunning()) return;
        stopping = true;
        stopReq.set(true);
        Log2.log("Stopping (finishing the current step)...");
        Thread t = thread;
        if (t != null) t.interrupt();
    }

    public void shopNow() {
        if (!isRunning()) start();
        shopNowReq.set(true);
        Log2.log("Shop check requested.");
    }

    // ================================================================ main loop
    private void runLoop() {
        try {
            Log2.log("Running. Watching for Roblox.");
            if (cfg.shopEnabled)
                Log2.log("Shop check every " + cfg.shopIntervalMin + " min for: "
                        + (cfg.buyRarities.isEmpty() ? "nothing" : String.join(", ", cfg.buyRarities)));
            long interval = cfg.shopIntervalMin * 60_000L;
            long nextShop = cfg.shopCheckOnStart ? System.currentTimeMillis()
                    : System.currentTimeMillis() + interval;
            String warned = null;
            while (!stopReq.get()) {
                interval = cfg.shopIntervalMin * 60_000L;
                nextShopAt = cfg.shopEnabled ? nextShop : 0;
                if (!dev.robloxForeground()) {
                    status = "Waiting for Roblox";
                    if (!"bg".equals(warned)) { Log2.log("Roblox isn't on screen - open it and the helper continues."); warned = "bg"; }
                    sleep(cfg.idleScanMs);
                    continue;
                }
                warned = null;
                status = "Running";
                boolean forced = shopNowReq.get();
                try {
                    if (cfg.retryEnabled && !forced && checkRetry()) {
                        sleep(cfg.clickCooldownMs);
                        continue;
                    }
                    if (forced || (cfg.shopEnabled && System.currentTimeMillis() >= nextShop)) {
                        shopNowReq.set(false);
                        status = "Checking shop";
                        checkShop();
                        nextShop = System.currentTimeMillis() + interval;
                    }
                } catch (InterruptedException ie) {
                    break;
                } catch (Exception e) {
                    Log2.log("Error: " + e);
                    nextShop = System.currentTimeMillis() + interval;
                }
                sleep(cfg.retryEnabled ? 50 : cfg.idleScanMs);   // capture itself is rate-limited
            }
        } catch (InterruptedException ignored) {
        } finally {
            dev.setControlsHidden(false);
            status = "Stopped";
            nextShopAt = 0;
            stopping = false;
            Log2.log("Stopped.");
        }
    }

    private void sleep(long ms) throws InterruptedException {
        if (stopReq.get()) throw new InterruptedException();
        Thread.sleep(ms);
    }

    private Frame capture() throws InterruptedException {
        if (stopReq.get()) throw new InterruptedException();
        return dev.capture();
    }

    private long frames(int n) { return Math.round(n * 1000.0 / cfg.gameFps); }

    private void tap(int x, int y, long ms) throws InterruptedException {
        if (stopReq.get()) throw new InterruptedException();
        if (cfg.hideWhileTapping) dev.setControlsHidden(true);
        try {
            dev.tap(x, y, ms);
        } finally {
            if (cfg.hideWhileTapping) dev.setControlsHidden(false);
        }
    }

    // ================================================================ Retry
    boolean checkRetry() throws InterruptedException {
        Frame f = capture();
        if (f == null) return false;
        Vision.Hit hit = Vision.findRetry(f, cfg.matchScore);
        if (hit == null) return false;
        long t0 = System.currentTimeMillis();
        boolean fast = fastFails < 2;
        tap(hit.x, hit.y, fast ? Math.max(frames(cfg.retryHoldFrames), 50) : 120);
        sleep(frames(cfg.retryAfterFrames));
        long took = System.currentTimeMillis() - t0;
        if (!retryGone(1200)) {
            if (fast) {
                fastFails++;
                Log2.log("Retry didn't register with the quick tap - tapping again (longer)");
                tap(hit.x, hit.y, 120);
                if (fastFails >= 2) Log2.log("Quick taps keep missing - using the longer tap from now on");
            }
            if (!retryGone(1200)) {
                Log2.log("Retry button is still there - will try again");
                return true;
            }
        } else if (fast) {
            fastFails = 0;
        }
        retries++;
        Log2.log(String.format(Locale.ROOT, "Retry tapped in %d ms (match %.2f)", took, hit.score));
        return true;
    }

    private boolean retryGone(long timeoutMs) throws InterruptedException {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            Frame f = capture();
            if (f != null && Vision.findRetry(f, cfg.matchScore) == null) return true;
        }
        return false;
    }

    // ================================================================ shop
    private interface FrameTest { boolean ok(Frame f); }

    private Frame waitFor(FrameTest test, long timeoutMs) throws InterruptedException {
        long end = System.currentTimeMillis() + timeoutMs;
        do {
            Frame f = capture();
            if (f != null && test.ok(f)) return f;
        } while (System.currentTimeMillis() < end);
        return null;
    }

    private int px(float frac, boolean xAxis) { return Math.round(frac * (xAxis ? dev.width() : dev.height())); }

    // state for one shop check
    private Vision.Box region;
    private int listX, listY;
    private boolean shopStop;

    void checkShop() throws InterruptedException {
        long t0 = System.currentTimeMillis();
        Log2.log("Checking the spawner shop...");
        int boughtBefore = buys;
        shopStop = false;

        Frame f = capture();
        if (f == null) { Log2.log("Couldn't take a screenshot."); return; }
        if (Vision.robuxPromptOpen(f)) {
            Log2.log("A Roblox purchase popup is open - closing it and skipping this check.");
            dev.back();
            return;
        }
        if (!Vision.shopIsOpen(f)) {
            tap(px(cfg.spawnersButton[0], true), px(cfg.spawnersButton[1], false), 80);
            f = waitFor(Vision::shopIsOpen, 2500);
        }
        if (f == null) {
            Log2.log("Shop didn't open. Tap Calibrate to set the SPAWNERS button.");
            return;
        }

        Vision.Buttons b = Vision.findShopButtons(f, null);
        int left = Integer.MAX_VALUE, right = 0;
        for (Vision.Box x : b.all()) { left = Math.min(left, x.x0); right = Math.max(right, x.x1); }
        int width = right - left;
        region = new Vision.Box((int) (left - width * 0.12), 0, (int) (right + width * 0.12), f.h);
        int[] close = Vision.findCloseButton(f, b.all());
        if (close == null) close = new int[]{px(cfg.shopCloseButton[0], true), px(cfg.shopCloseButton[1], false)};
        listX = (left + right) / 2;
        listY = px(cfg.shopListPoint[1], false);

        if (cfg.quickScan) {
            // Legendary/Mythic/Secret are the last 3 rows. Go to the bottom, then step up
            // until we've looked at the row with the Epics (that row also has Ice Cave).
            scrollToEnd(true);
            Vision.ShopView v = checkView("bottom");
            String sig = v == null ? null : currentSig();
            for (int i = 1; i <= 8 && v != null && !shopStop && !v.hasRarity("Epic"); i++) {
                scrollStep(false);
                String s2 = currentSig();
                if (s2 != null && s2.equals(sig)) break;   // didn't move -> top
                v = checkView("bottom-" + i);
                sig = currentSig();
            }
        } else {
            scrollToEnd(false);
            for (int page = 1; page <= 30 && !shopStop; page++) {
                Vision.ShopView v = checkView("page " + page);
                if (v == null) break;
                String before = currentSig();
                scrollStep(true);
                String after = currentSig();
                if (after != null && after.equals(before)) break;   // didn't move -> bottom
            }
        }

        // ---- close the shop
        Frame now = capture();
        if (now != null && Vision.shopIsOpen(now)) {
            tap(close[0], close[1], 80);
            if (waitFor(fr -> !Vision.shopIsOpen(fr), 1500) == null) {
                tap(px(cfg.shopCloseButton[0], true), px(cfg.shopCloseButton[1], false), 80);
                if (waitFor(fr -> !Vision.shopIsOpen(fr), 1500) == null) Log2.log("Couldn't close the shop.");
            }
        }
        shopChecks++;
        Log2.log(String.format(Locale.ROOT, "Shop check done in %.1fs. Tapped Buy %d time(s).",
                (System.currentTimeMillis() - t0) / 1000.0, buys - boughtBefore));
    }

    /** One finger drag on the list. down=true shows LOWER items (finger moves up). */
    private void scrollStep(boolean down) throws InterruptedException {
        int d = (int) (dev.height() * 0.30);
        int yA = listY + d / 2, yB = listY - d / 2;
        if (cfg.hideWhileTapping) dev.setControlsHidden(true);
        try {
            if (down) dev.swipe(listX, yA, yB, 600); else dev.swipe(listX, yB, yA, 600);
        } finally {
            if (cfg.hideWhileTapping) dev.setControlsHidden(false);
        }
        settle();
    }

    /** Swipe until the list stops moving. bottom=true -> end of the list, false -> top. */
    private void scrollToEnd(boolean bottom) throws InterruptedException {
        String last = null;
        for (int i = 0; i < 10; i++) {
            int d = (int) (dev.height() * 0.45);
            int yA = listY + d / 2, yB = listY - d / 2;
            if (cfg.hideWhileTapping) dev.setControlsHidden(true);
            try {
                if (bottom) dev.swipe(listX, yA, yB, 250); else dev.swipe(listX, yB, yA, 250);
            } finally {
                if (cfg.hideWhileTapping) dev.setControlsHidden(false);
            }
            Frame f = settle();
            if (f == null) continue;
            String s = Vision.viewSig(f, region);
            if (s.equals(last)) return;
            last = s;
        }
    }

    /** Wait until two screenshots in a row show the list in the same place (scroll momentum over). */
    private Frame settle() throws InterruptedException {
        String prev = null;
        Frame f = null;
        for (int i = 0; i < 6; i++) {
            f = capture();
            if (f == null) continue;
            String s = Vision.viewSig(f, region);
            if (s.equals(prev)) return f;
            prev = s;
        }
        return f;
    }

    private String currentSig() throws InterruptedException {
        Frame f = capture();
        return f == null ? null : Vision.viewSig(f, region);
    }

    /** Look at the current view and buy wanted cards. Returns null to stop the shop check. */
    private Vision.ShopView checkView(String name) throws InterruptedException {
        int tries = 0;
        while (true) {
            Frame a = capture();
            Frame b = capture();          // >= 1/3 s later: Android's screenshot limit
            if (a == null || b == null) return null;
            Vision.ShopView v = Vision.readShop(a, b, region, cfg.buyRarities);
            if (tries == 0) {
                List<String> inStock = new ArrayList<>();
                for (Vision.Card c : v.cards) if (c.inStock) inStock.add(c.rarity);
                Log2.log("  " + name + ": in stock = " + (inStock.isEmpty() ? "nothing" : String.join(", ", inStock)));
                if (cfg.debug) dev.saveDebug(b, name.replace(' ', '_'));
            }
            if (v.wanted.isEmpty()) return v;
            if (tries == 0) dev.alert();
            if (!cfg.autoBuy) {
                List<String> w = new ArrayList<>();
                for (Vision.Card c : v.wanted) w.add(c.rarity);
                Log2.log("  " + String.join(", ", w) + " in stock! (auto buy is off)");
                return v;
            }
            if (tries >= 5 || buys >= cfg.maxBuysPerCheck) return v;
            Vision.Card c = v.wanted.get(0);
            Log2.log("  " + c.rarity + " in stock - tapping Buy");
            tap(c.box.cx(), c.box.cy(), 80);
            buys++;
            tries++;
            sleep(800);
            Frame chk = capture();
            if (chk != null && cfg.safetyStopOnRobuxPopup && Vision.robuxPromptOpen(chk)) {
                Log2.log("  !! A Robux purchase popup opened - closing it and stopping (nothing bought with Robux).");
                dev.back();
                shopStop = true;
                return null;
            }
        }
    }
}
