package com.btdhelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Activity log shown in the panel (same colour classes as the PC app). */
public final class Log2 {
    public static final class Line {
        public final String time, msg, kind;
        Line(String t, String m, String k) { time = t; msg = m; kind = k; }
    }

    private static final List<Line> lines = new ArrayList<>();
    private static int base = 0;   // index of lines[0] in the full history

    private Log2() {}

    public static String classify(String msg) {
        String m = msg.toLowerCase(Locale.ROOT);
        if (m.contains("error") || m.contains("couldn't") || m.contains("!!") || m.contains("failed")) return "err";
        if (m.contains("tapping buy") || m.contains("bought")) return "buy";
        if (m.contains("retry") && (m.contains("tapped") || m.contains("found"))) return "retry";
        if (m.contains("shop") || m.contains("view") || m.contains("in stock") || m.contains("bottom")) return "shop";
        if (m.contains("running") || m.contains("saved") || m.contains("done") || m.contains("ready")) return "ok";
        return "";
    }

    public static void log(String msg) { add(msg, null); }

    public static synchronized void add(String msg, String kind) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date());
        lines.add(new Line(t, msg, kind != null ? kind : classify(msg)));
        android.util.Log.i("BTDHelper", msg);
        if (lines.size() > 1000) {
            int drop = lines.size() - 800;
            lines.subList(0, drop).clear();
            base += drop;
        }
    }

    public static synchronized int total() { return base + lines.size(); }

    public static synchronized List<Line> since(int index) {
        int start = Math.max(0, index - base);
        if (start >= lines.size()) return new ArrayList<>();
        return new ArrayList<>(lines.subList(start, lines.size()));
    }
}
