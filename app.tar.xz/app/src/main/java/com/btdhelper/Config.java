package com.btdhelper;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * All settings, saved between runs (PC: auto_retry_settings.json + auto_retry_points.json).
 * Positions are fractions of the screen, measured from the mobile screenshots, and can be
 * re-measured with Calibrate.
 */
public final class Config {
    private final SharedPreferences sp;

    // ---- switches (same names as the PC version)
    public volatile boolean retryEnabled, shopEnabled, autoBuy, quickScan, hideWhileTapping, shopCheckOnStart, debug;
    public volatile int shopIntervalMin;
    public volatile List<String> buyRarities = new ArrayList<>();

    // ---- fixed tuning (same values/meaning as PC unless noted)
    public final int gameFps = 60;
    public final int retryHoldFrames = 3;          // tap held for 3 frames (50 ms) at 60 FPS
    public final int retryAfterFrames = 4;         // wait after the tap before looking again
    public final double matchScore = 0.75;         // how closely the text must look like "Retry"
    public final long retryScanMs = 350;           // Android allows one screenshot per ~1/3 s
    public final long idleScanMs = 1000;
    public final long clickCooldownMs = 1000;
    public final int maxBuysPerCheck = 10;
    public final boolean safetyStopOnRobuxPopup = true;

    // ---- positions (fractions of the screen). Defaults measured on your phone's screenshots.
    public volatile float[] spawnersButton, shopCloseButton, shopListPoint;

    public static final float[] DEF_SPAWNERS = {0.9206f, 0.3862f};
    public static final float[] DEF_CLOSE = {0.8138f, 0.0976f};
    public static final float[] DEF_LIST = {0.5000f, 0.6098f};

    public Config(Context ctx) {
        sp = ctx.getSharedPreferences("btd_helper", Context.MODE_PRIVATE);
        load();
    }

    public void load() {
        retryEnabled = sp.getBoolean("retry_enabled", true);
        shopEnabled = sp.getBoolean("shop_enabled", true);
        autoBuy = sp.getBoolean("auto_buy", true);
        quickScan = sp.getBoolean("quick_scan", true);
        hideWhileTapping = sp.getBoolean("hide_while_tapping", true);
        shopCheckOnStart = sp.getBoolean("shop_check_on_start", true);
        debug = sp.getBoolean("debug", false);
        shopIntervalMin = sp.getInt("shop_interval_min", 5);
        String r = sp.getString("buy_rarities", "Legendary,Mythic");
        buyRarities = r.isEmpty() ? new ArrayList<>() : new ArrayList<>(Arrays.asList(r.split(",")));
        spawnersButton = point("spawners_button", DEF_SPAWNERS);
        shopCloseButton = point("shop_close_button", DEF_CLOSE);
        shopListPoint = point("shop_list_point", DEF_LIST);
    }

    private float[] point(String key, float[] def) {
        return new float[]{sp.getFloat(key + "_x", def[0]), sp.getFloat(key + "_y", def[1])};
    }

    public void save() {
        sp.edit()
                .putBoolean("retry_enabled", retryEnabled)
                .putBoolean("shop_enabled", shopEnabled)
                .putBoolean("auto_buy", autoBuy)
                .putBoolean("quick_scan", quickScan)
                .putBoolean("hide_while_tapping", hideWhileTapping)
                .putBoolean("shop_check_on_start", shopCheckOnStart)
                .putBoolean("debug", debug)
                .putInt("shop_interval_min", shopIntervalMin)
                .putString("buy_rarities", String.join(",", buyRarities))
                .putFloat("spawners_button_x", spawnersButton[0]).putFloat("spawners_button_y", spawnersButton[1])
                .putFloat("shop_close_button_x", shopCloseButton[0]).putFloat("shop_close_button_y", shopCloseButton[1])
                .putFloat("shop_list_point_x", shopListPoint[0]).putFloat("shop_list_point_y", shopListPoint[1])
                .apply();
    }

    /** Set a switch by its PC name. Returns false for unknown keys. */
    public boolean setSwitch(String key, boolean v) {
        switch (key) {
            case "retry_enabled": retryEnabled = v; break;
            case "shop_enabled": shopEnabled = v; break;
            case "auto_buy": autoBuy = v; break;
            case "quick_scan": quickScan = v; break;
            case "hide_while_tapping": hideWhileTapping = v; break;
            case "shop_check_on_start": shopCheckOnStart = v; break;
            case "debug": debug = v; break;
            default: return false;
        }
        save();
        return true;
    }

    public void setRarity(String name, boolean on) {
        List<String> order = Arrays.asList("Legendary", "Mythic", "Secret");
        if (!order.contains(name)) return;
        List<String> r = new ArrayList<>();
        for (String o : order) if (o.equals(name) ? on : buyRarities.contains(o)) r.add(o);
        buyRarities = r;
        save();
    }

    /** Same steps as the PC stepper: 1-minute steps up to 10, then 5-minute steps (1..120). */
    public void stepInterval(int delta) {
        int m = shopIntervalMin;
        if (delta > 0) m = m < 10 ? m + 1 : m + 5;
        else m = m <= 10 ? m - 1 : m - 5;
        shopIntervalMin = Math.max(1, Math.min(120, m));
        save();
    }
}
