package com.btdhelper;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebView;

/** The app screen: setup steps + the same control panel as the floating one. */
public class MainActivity extends Activity {
    private WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Hub.init(this);
        getWindow().setStatusBarColor(Color.parseColor("#0c1120"));
        getWindow().setNavigationBarColor(Color.parseColor("#0c1120"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0c1120"));
        web.getSettings().setJavaScriptEnabled(true);
        web.addJavascriptInterface(new Bridge(this, false), "BTD");
        web.loadUrl("file:///android_asset/panel.html?mode=app");
        setContentView(web);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
