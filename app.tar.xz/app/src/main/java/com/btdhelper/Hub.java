package com.btdhelper;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Shared app state: settings, the engine and the running Accessibility service. */
public final class Hub {
    public static volatile Config cfg;
    public static volatile Engine engine;
    public static volatile HelperService service;
    public static final Handler main = new Handler(Looper.getMainLooper());
    private static boolean inited;
    private static File crashFile;

    private Hub() {}

    public static synchronized void init(Context ctx) {
        if (inited) return;
        inited = true;
        Context app = ctx.getApplicationContext();
        cfg = new Config(app);
        File dir = app.getExternalFilesDir(null);
        crashFile = new File(dir != null ? dir : app.getFilesDir(), "crash_log.txt");
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            writeCrash(e);
            if (prev != null) prev.uncaughtException(t, e);
        });
        Log2.add("Ready. Turn the helper on, open Roblox, then press Start.", "muted");
    }

    public static void writeCrash(Throwable e) {
        try (FileWriter w = new FileWriter(crashFile, true)) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            w.write("\n===== " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new Date())
                    + " =====\n" + sw + "\n");
        } catch (Exception ignored) {
        }
    }
}
