package com.btdhelper;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/** What the control panel (panel.html) can call - the same actions as the PC app's buttons. */
public final class Bridge {
    private final Context ctx;
    private final boolean overlay;

    public Bridge(Context ctx, boolean overlay) {
        this.ctx = ctx;
        this.overlay = overlay;
        Hub.init(ctx);
    }

    @JavascriptInterface
    public String getState(int since) {
        try {
            Engine en = Hub.engine;
            Config c = Hub.cfg;
            HelperService svc = Hub.service;
            boolean running = en != null && en.isRunning();
            JSONObject s = new JSONObject();
            s.put("service", svc != null);
            s.put("overlay", overlay);
            s.put("running", running);
            s.put("stopping", en != null && en.isStopping());
            s.put("status", running ? en.status : "Stopped");
            s.put("calibrating", svc != null && svc.isCalibrating());
            JSONObject st = new JSONObject();
            st.put("retries", en == null ? 0 : en.retries);
            st.put("buys", en == null ? 0 : en.buys);
            st.put("shop_checks", en == null ? 0 : en.shopChecks);
            long next = en == null ? 0 : en.nextShopAt;
            st.put("next_in", running && next > 0 && c.shopEnabled
                    ? Math.max(0, (next - System.currentTimeMillis()) / 1000) : JSONObject.NULL);
            s.put("stats", st);
            JSONObject cf = new JSONObject();
            cf.put("retry_enabled", c.retryEnabled);
            cf.put("shop_enabled", c.shopEnabled);
            cf.put("auto_buy", c.autoBuy);
            cf.put("quick_scan", c.quickScan);
            cf.put("hide_while_tapping", c.hideWhileTapping);
            cf.put("shop_check_on_start", c.shopCheckOnStart);
            cf.put("debug", c.debug);
            cf.put("shop_interval_min", c.shopIntervalMin);
            cf.put("buy_rarities", new JSONArray(c.buyRarities));
            s.put("config", cf);
            if (since >= 0) {
                JSONArray logs = new JSONArray();
                List<Log2.Line> lines = Log2.since(since);
                for (Log2.Line l : lines) logs.put(new JSONArray().put(l.time).put(l.msg).put(l.kind));
                s.put("logs", logs);
                s.put("log_total", Log2.total());
            }
            return s.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @JavascriptInterface
    public void toggleRun() {
        Engine en = Hub.engine;
        if (en == null) { Log2.log("Turn the helper on first (Accessibility settings)."); return; }
        if (en.isRunning()) {
            en.stop();
        } else {
            en.start();
            HelperService s = Hub.service;
            if (s != null && overlay) s.openPanel(false);    // get out of the way of the game
        }
    }

    @JavascriptInterface
    public void shopNow() {
        Engine en = Hub.engine;
        if (en == null) { Log2.log("Turn the helper on first (Accessibility settings)."); return; }
        en.shopNow();
        HelperService s = Hub.service;
        if (s != null && overlay) s.openPanel(false);
    }

    @JavascriptInterface
    public void calibrate() {
        HelperService s = Hub.service;
        if (s == null) { Log2.log("Turn the helper on first (Accessibility settings)."); return; }
        if (Hub.engine != null && Hub.engine.isRunning()) { Log2.log("Stop the helper first, then calibrate."); return; }
        if (!overlay) { Log2.log("Open Roblox, tap the floating button, then Calibrate there."); return; }
        s.startCalibration();
    }

    @JavascriptInterface
    public void setSetting(String key, boolean value) { Hub.cfg.setSwitch(key, value); }

    @JavascriptInterface
    public void setRarity(String name, boolean on) { Hub.cfg.setRarity(name, on); }

    @JavascriptInterface
    public void stepInterval(int delta) { Hub.cfg.stepInterval(delta); }

    @JavascriptInterface
    public void collapse() {
        HelperService s = Hub.service;
        if (s != null) s.openPanel(false);
    }

    @JavascriptInterface
    public void openAccessibility() {
        Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    @JavascriptInterface
    public void openRoblox() {
        Intent i = ctx.getPackageManager().getLaunchIntentForPackage(HelperService.ROBLOX);
        if (i == null) { Log2.log("Couldn't find the Roblox app."); return; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }
}
