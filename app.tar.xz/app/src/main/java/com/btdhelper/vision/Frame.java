package com.btdhelper.vision;

/** A captured screen image: w x h pixels, packed as 0xAARRGGBB (same as Android Bitmap.getPixels). */
public final class Frame {
    public final int w, h;
    public final int[] px;

    public Frame(int w, int h, int[] px) {
        this.w = w;
        this.h = h;
        this.px = px;
    }

    public int r(int x, int y) { return (px[y * w + x] >> 16) & 0xFF; }
    public int g(int x, int y) { return (px[y * w + x] >> 8) & 0xFF; }
    public int b(int x, int y) { return px[y * w + x] & 0xFF; }
    public int rgb(int x, int y) { return px[y * w + x]; }
}
