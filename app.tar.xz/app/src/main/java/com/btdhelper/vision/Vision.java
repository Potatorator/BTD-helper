package com.btdhelper.vision;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Everything the helper "sees": Retry button, shop buttons, rarity labels, the shop's X,
 * the scrollbar and Roblox's real-money purchase popup.
 *
 * This is a direct port of the PC version (auto_retry.py), adapted to the mobile game:
 *  - mobile Buy buttons are ORANGE (PC: green) - both are accepted;
 *  - mobile shop shows ~1 row at a time;
 *  - rarity labels are also read for Epic/Rare/Uncommon so the quick scan knows where it is.
 * Pure Java (no Android classes) so it can be unit-tested on screenshots.
 */
public final class Vision {

    private Vision() {}

    /** Axis-aligned box [x0, y0, x1, y1). */
    public static final class Box {
        public final int x0, y0, x1, y1;
        public Box(int x0, int y0, int x1, int y1) { this.x0 = x0; this.y0 = y0; this.x1 = x1; this.y1 = y1; }
        public int w() { return x1 - x0; }
        public int h() { return y1 - y0; }
        public int cx() { return (x0 + x1) / 2; }
        public int cy() { return (y0 + y1) / 2; }
        @Override public String toString() { return "[" + x0 + "," + y0 + "," + x1 + "," + y1 + "]"; }
        @Override public boolean equals(Object o) {
            if (!(o instanceof Box)) return false;
            Box b = (Box) o;
            return b.x0 == x0 && b.y0 == y0 && b.x1 == x1 && b.y1 == y1;
        }
        @Override public int hashCode() { return Arrays.hashCode(new int[]{x0, y0, x1, y1}); }
    }

    public interface Pred { boolean test(int r, int g, int b); }

    // ------------------------------------------------------------------ colours
    public static boolean isBlue(int r, int g, int b) { return b >= 170 && b - r >= 90 && g - r >= 45; }
    public static boolean isWhite(int r, int g, int b) { return r >= 215 && g >= 215 && b >= 215; }
    /** PC Buy button. */
    public static boolean isBuyGreen(int r, int g, int b) { return g >= 120 && g - r >= 50 && g - b >= 40 && r <= 140; }
    /** Mobile Buy button: orange, (217,148,106) at the top to (166,80,63) at the bottom. */
    public static boolean isBuyOrange(int r, int g, int b) {
        int rg = r - g, gb = g - b;
        return r >= 150 && rg >= 45 && rg <= 115 && gb >= 8 && gb <= 55 && b <= 130;
    }
    public static boolean isBuy(int r, int g, int b) { return isBuyOrange(r, g, b) || isBuyGreen(r, g, b); }
    public static boolean isSoldGray(int r, int g, int b) {
        return r >= 100 && r <= 175 && g - r >= 0 && g - r <= 12 && b - g >= 5 && b - g <= 20;
    }
    public static boolean isCloseRed(int r, int g, int b) { return r >= 180 && r - g >= 85 && r - b >= 65; }
    public static boolean isThumb(int r, int g, int b) {
        return r >= 105 && r <= 180 && Math.abs(r - g) <= 12 && r - b >= -8 && r - b <= 50;
    }

    // ------------------------------------------------------------------ blob finder
    /** Find blobs of pixels matching pred on a coarse grid; return box-shaped ones. */
    public static List<Box> findBoxes(Frame f, Pred pred, int step, int minW, int minH,
                                      double aspMin, double aspMax, double fill, Box region) {
        int rx0 = 0, ry0 = 0, rx1 = f.w, ry1 = f.h;
        if (region != null) {
            rx0 = Math.max(0, region.x0); ry0 = Math.max(0, region.y0);
            rx1 = Math.min(f.w, region.x1); ry1 = Math.min(f.h, region.y1);
        }
        int gw = Math.max(0, (rx1 - rx0) / step), gh = Math.max(0, (ry1 - ry0) / step);
        byte[] grid = new byte[gw * gh];
        int[] px = f.px;
        for (int gy = 0; gy < gh; gy++) {
            int row = (ry0 + gy * step) * f.w + rx0;
            for (int gx = 0; gx < gw; gx++) {
                int c = px[row + gx * step];
                if (pred.test((c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF)) grid[gy * gw + gx] = 1;
            }
        }
        List<Box> out = new ArrayList<>();
        int[] stack = new int[Math.max(16, gw * gh)];
        for (int start = 0; start < grid.length; start++) {
            if (grid[start] != 1) continue;
            grid[start] = 2;
            int sp = 0;
            stack[sp++] = start;
            int n = 0, x0 = start % gw, x1 = x0, y0 = start / gw, y1 = y0;
            while (sp > 0) {
                int idx = stack[--sp];
                n++;
                int cx = idx % gw, cy = idx / gw;
                if (cx < x0) x0 = cx; else if (cx > x1) x1 = cx;
                if (cy < y0) y0 = cy; else if (cy > y1) y1 = cy;
                if (cx + 1 < gw && grid[idx + 1] == 1) { grid[idx + 1] = 2; stack[sp++] = idx + 1; }
                if (cx > 0 && grid[idx - 1] == 1) { grid[idx - 1] = 2; stack[sp++] = idx - 1; }
                if (cy + 1 < gh && grid[idx + gw] == 1) { grid[idx + gw] = 2; stack[sp++] = idx + gw; }
                if (cy > 0 && grid[idx - gw] == 1) { grid[idx - gw] = 2; stack[sp++] = idx - gw; }
            }
            int bw = (x1 - x0 + 1) * step, bh = (y1 - y0 + 1) * step;
            double asp = (double) bw / bh;
            double fl = (double) n / ((x1 - x0 + 1) * (y1 - y0 + 1));
            if (bw >= minW && bh >= minH && asp >= aspMin && asp <= aspMax && fl >= fill) {
                out.add(new Box(rx0 + x0 * step, ry0 + y0 * step, rx0 + (x1 + 1) * step, ry0 + (y1 + 1) * step));
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ Retry
    static final int TW = 24, TH = 8;
    static final String REF_MASK =
            "111110000000110000000000" +
            "111110001000110110011001" +
            "110111111111111111111011" +
            "111110111110110110001111" +
            "111110111110110110001110" +
            "110110011110111110001110" +
            "110010001000000010011100" +
            "000000000000000000001000";
    static final boolean[] REF = new boolean[TW * TH];
    static final int REF_COUNT;
    static {
        int c = 0;
        for (int i = 0; i < REF.length; i++) { REF[i] = REF_MASK.charAt(i) == '1'; if (REF[i]) c++; }
        REF_COUNT = c;
    }

    static Box textBox(Frame f, Box b) {
        int x0 = b.x0, y0 = b.y0, x1 = Math.min(b.x1, f.w), y1 = Math.min(b.y1, f.h);
        int mx = (x1 - x0) / 12, my = (y1 - y0) / 8;
        int tx0 = Integer.MAX_VALUE, ty0 = Integer.MAX_VALUE, tx1 = -1, ty1 = -1, n = 0;
        for (int y = y0 + my; y < y1 - my; y++)
            for (int x = x0 + mx; x < x1 - mx; x++)
                if (isWhite(f.r(x, y), f.g(x, y), f.b(x, y))) {
                    n++;
                    if (x < tx0) tx0 = x; if (x > tx1) tx1 = x;
                    if (y < ty0) ty0 = y; if (y > ty1) ty1 = y;
                }
        if (n < 10) return null;
        return new Box(tx0, ty0, tx1 + 1, ty1 + 1);
    }

    static double textScore(Frame f, Box t) {
        double bw = (double) t.w() / TW, bh = (double) t.h() / TH;
        int inter = 0, count = 0;
        for (int j = 0; j < TH; j++)
            for (int i = 0; i < TW; i++) {
                int c = 0;
                for (int sj = 0; sj < 3; sj++)
                    for (int si = 0; si < 3; si++) {
                        int x = (int) (t.x0 + (i + (si + 0.5) / 3) * bw);
                        int y = (int) (t.y0 + (j + (sj + 0.5) / 3) * bh);
                        x = Math.min(x, f.w - 1); y = Math.min(y, f.h - 1);
                        if (isWhite(f.r(x, y), f.g(x, y), f.b(x, y))) c++;
                    }
                if (c >= 3) { count++; if (REF[j * TW + i]) inter++; }
            }
        int total = count + REF_COUNT;
        return total > 0 ? 2.0 * inter / total : 0;
    }

    public static final class Hit {
        public final int x, y; public final double score; public final Box box;
        Hit(Box b, double s) { this.box = b; this.x = b.cx(); this.y = b.cy(); this.score = s; }
    }

    /** The blue Retry button (never Revive, Close or Skip Wave), or null. */
    public static Hit findRetry(Frame f, double minScore) {
        int step = Math.max(2, Math.round(Math.max(f.w, f.h) / 640f));
        Hit best = null;
        for (Box b : findBoxes(f, Vision::isBlue, step, Math.max(30, f.w / 40), 12, 1.5, 6.0, 0.5, null)) {
            Box t = textBox(f, b);
            if (t == null) continue;
            double s = textScore(f, t);
            if (s >= minScore && (best == null || s > best.score)) best = new Hit(b, s);
        }
        return best;
    }

    // ------------------------------------------------------------------ shop
    public static final class Buttons {
        public final List<Box> buy = new ArrayList<>(), sold = new ArrayList<>();
        public List<Box> all() { List<Box> a = new ArrayList<>(buy); a.addAll(sold); return a; }
        public int count() { return buy.size() + sold.size(); }
    }

    static List<Box> consistent(List<Box> boxes) {
        if (boxes.isEmpty()) return boxes;
        int[] ws = new int[boxes.size()], hs = new int[boxes.size()];
        for (int i = 0; i < ws.length; i++) { ws[i] = boxes.get(i).w(); hs[i] = boxes.get(i).h(); }
        Arrays.sort(ws); Arrays.sort(hs);
        int mw = ws[ws.length / 2], mh = hs[hs.length / 2];
        List<Box> out = new ArrayList<>();
        for (Box b : boxes)
            if (Math.abs(b.w() - mw) <= mw * 0.2 && Math.abs(b.h() - mh) <= mh * 0.3) out.add(b);
        return out;
    }

    /** Buy (orange/green) and Sold out (grey) buttons of shop cards. */
    public static Buttons findShopButtons(Frame f, Box region) {
        int minW = Math.max(40, f.w / 30);
        int step = Math.max(2, Math.round(Math.max(f.w, f.h) / 800f));
        List<Box> buy = findBoxes(f, Vision::isBuy, step, minW, 15, 2.3, 7, 0.5, region);
        List<Box> sold = findBoxes(f, Vision::isSoldGray, step, minW, 15, 2.3, 7, 0.5, region);
        List<Box> all = new ArrayList<>(buy); all.addAll(sold);
        List<Box> keep = consistent(all);
        Buttons out = new Buttons();
        for (Box b : buy) if (keep.contains(b)) out.buy.add(b);
        for (Box b : sold) if (keep.contains(b)) out.sold.add(b);
        return out;
    }

    public static boolean shopIsOpen(Frame f) { return findShopButtons(f, null).count() >= 3; }

    /** Hue (0..360), saturation, value of a packed colour. */
    static float[] hsv(int r, int g, int b) {
        float rf = r / 255f, gf = g / 255f, bf = b / 255f;
        float mx = Math.max(rf, Math.max(gf, bf)), mn = Math.min(rf, Math.min(gf, bf)), d = mx - mn;
        float h;
        if (d == 0) h = 0;
        else if (mx == rf) h = 60 * (((gf - bf) / d) % 6);
        else if (mx == gf) h = 60 * ((bf - rf) / d + 2);
        else h = 60 * ((rf - gf) / d + 4);
        if (h < 0) h += 360;
        return new float[]{h, mx == 0 ? 0 : d / mx, mx};
    }

    /**
     * Read the coloured rarity label under the card's name. It sits ~2.45-2.95 button-heights
     * above the Buy/Sold-out button. Returns Legendary, Mythic, Epic, Rare, Uncommon, Other, or null.
     */
    public static String labelRarity(Frame f, Box b) {
        int bh = b.h();
        int ya = Math.max(0, (int) (b.y0 - 2.95 * bh)), yb = Math.max(0, (int) (b.y0 - 2.45 * bh));
        float[] hues = new float[Math.max(1, (yb - ya) * b.w())];
        int n = 0, neutralDark = 0, area = 0;
        for (int y = ya; y < yb; y++)
            for (int x = b.x0; x < b.x1 && x < f.w; x++) {
                int r = f.r(x, y), g = f.g(x, y), bl = f.b(x, y);
                float[] v = hsv(r, g, bl);
                if (v[1] >= 0.45f && v[2] >= 0.7f) hues[n++] = v[0];
                int mx = Math.max(r, Math.max(g, bl)), mn = Math.min(r, Math.min(g, bl));
                if (mx - mn <= 12 && mx >= 12 && mx <= 140) neutralDark++;
                area++;
            }
        // Secret: the label is a dark grey box with grey "SECRET" text (no colour at all)
        if (area > 0 && neutralDark >= area * 0.12) return "Secret";
        if (n < 10) return null;
        float[] hs = Arrays.copyOf(hues, n);
        Arrays.sort(hs);
        float maxGap = 0;
        for (int i = 0; i < n; i++) {
            float gap = (i + 1 < n ? hs[i + 1] - hs[i] : hs[0] + 360 - hs[i]);
            if (gap > maxGap) maxGap = gap;
        }
        float spread = 360 - maxGap;
        float median = hs[n / 2];
        if (spread >= 55 && n >= 20) return "Mythic";
        if (spread <= 45) {
            if (median >= 20 && median <= 55) return "Legendary";
            if (median >= 255 && median <= 300) return "Epic";
            if (median >= 195 && median <= 235) return "Rare";
            if (median >= 95 && median <= 150) return "Uncommon";
        }
        return "Other";
    }

    // PC border fallback (only trusted for an exact orange Legendary border)
    static int[] cardBorder(Frame f, Box b) {
        int cy = b.cy(), cw = b.w();
        int need = Math.max(5, cw / 30);
        int[] bg = null, prev = null;
        int run = 0;
        for (int x = b.x0 - 1; x > Math.max(1, b.x0 - (int) (cw * 0.2)); x--) {
            int[] p = {f.r(x, cy), f.g(x, cy), f.b(x, cy)};
            if (bg == null) {
                run = (prev != null && diff(p, prev) <= 12) ? run + 1 : 0;
                if (run >= need) bg = p;
            } else if (diff(p, bg) > 60) {
                return new int[]{f.r(x - 1, cy), f.g(x - 1, cy), f.b(x - 1, cy)};
            }
            prev = p;
        }
        return null;
    }

    static int diff(int[] p, int[] q) { return Math.abs(p[0] - q[0]) + Math.abs(p[1] - q[1]) + Math.abs(p[2] - q[2]); }

    public static String cardRarity(Frame f, Box b) {
        String r = labelRarity(f, b);
        if (r != null) return r;
        int[] p = cardBorder(f, b);
        if (p != null) {
            float[] v = hsv(p[0], p[1], p[2]);
            if (Math.abs(v[0] - 38) <= 10 && v[1] >= 0.75f && v[1] <= 0.92f && v[2] >= 0.85f) return "Legendary";
        }
        return "Other";
    }

    public static final class Card {
        public final String rarity; public final Box box; public final boolean inStock;
        Card(String r, Box b, boolean s) { rarity = r; box = b; inStock = s; }
    }

    public static final class ShopView {
        public final List<Card> cards = new ArrayList<>();      // every card with a visible button
        public final List<Card> wanted = new ArrayList<>();     // in stock, wanted, stable in both frames
        public Buttons buttons;
        public boolean hasRarity(String r) { for (Card c : cards) if (c.rarity.equals(r)) return true; return false; }
    }

    /**
     * Look at the shop. A card is only "wanted" if its Buy button is in the same place in two
     * frames taken a moment apart (the list isn't moving) and both frames agree on the rarity.
     */
    public static ShopView readShop(Frame a, Frame b, Box region, List<String> wantRarities) {
        Buttons ba = findShopButtons(a, region);
        Buttons bb = findShopButtons(b, region);
        ShopView v = new ShopView();
        v.buttons = bb;
        // Safety: only trust a real shop page (3+ card buttons in a grid)
        boolean realShop = bb.count() >= 3;
        for (Box s : bb.sold) v.cards.add(new Card(cardRarity(b, s), s, false));
        for (Box x : bb.buy) {
            String r2 = cardRarity(b, x);
            v.cards.add(new Card(r2, x, true));
            boolean same = false;
            for (Box y : ba.buy) if (Math.abs(y.x0 - x.x0) <= 4 && Math.abs(y.y0 - x.y0) <= 4) { same = true; break; }
            if (!same || !realShop || !inGrid(x, bb)) continue;
            String r1 = cardRarity(a, x);
            if (r1.equals(r2) && wantRarities.contains(r2)) v.wanted.add(new Card(r2, x, true));
        }
        return v;
    }

    /** True if the button lines up with at least one other card button (same row or column). */
    static boolean inGrid(Box x, Buttons all) {
        for (Box o : all.all()) {
            if (o.equals(x)) continue;
            if (Math.abs(o.y0 - x.y0) <= x.h() / 3 || Math.abs(o.cx() - x.cx()) <= x.w() / 4) return true;
        }
        return false;
    }

    /** The shop's red X: a square red button above the list, near its right edge. */
    public static int[] findCloseButton(Frame f, List<Box> buttons) {
        if (buttons.isEmpty()) return null;
        int left = Integer.MAX_VALUE, right = 0, top = Integer.MAX_VALUE;
        int[] ws = new int[buttons.size()];
        for (int i = 0; i < ws.length; i++) {
            Box b = buttons.get(i);
            left = Math.min(left, b.x0); right = Math.max(right, b.x1); top = Math.min(top, b.y0);
            ws[i] = b.w();
        }
        Arrays.sort(ws);
        int bw = ws[ws.length / 2], width = right - left;
        Box region = new Box((int) (right - width * 0.3), 0, (int) (right + width * 0.2), top);
        int[] best = null;
        int bestSize = 0;
        for (Box b : findBoxes(f, Vision::isCloseRed, 3, Math.max(10, bw / 6), 10, 0.6, 1.7, 0.4, region)) {
            if (b.w() > bw * 0.7) continue;
            int size = b.w() * b.h();
            if (size > bestSize) { bestSize = size; best = new int[]{b.cx(), b.cy()}; }
        }
        return best;
    }

    /** The scrollbar handle just right of the cards (used to know when we hit the bottom). */
    public static Box findScrollThumb(Frame f, List<Box> buttons) {
        if (buttons.isEmpty()) return null;
        int left = Integer.MAX_VALUE, right = 0;
        int[] hs = new int[buttons.size()];
        for (int i = 0; i < hs.length; i++) {
            left = Math.min(left, buttons.get(i).x0); right = Math.max(right, buttons.get(i).x1);
            hs[i] = buttons.get(i).h();
        }
        Arrays.sort(hs);
        int bh = hs[hs.length / 2];
        Box region = new Box(right, 0, (int) (right + (right - left) * 0.08), f.h);
        Box best = null;
        for (Box b : findBoxes(f, Vision::isThumb, 2, 3, bh, 0.01, 0.4, 0.6, region))
            if (best == null || b.h() > best.h()) best = b;
        return best;
    }

    /** Roblox's own real-money purchase popup: a dark grey panel in the middle of the screen. */
    public static boolean robuxPromptOpen(Frame f) {
        int cx0 = (int) (f.w * 0.40), cx1 = (int) (f.w * 0.60), cy0 = (int) (f.h * 0.38), cy1 = (int) (f.h * 0.52);
        int dark = 0, total = 0;
        for (int y = cy0; y < cy1; y += 4)
            for (int x = cx0; x < cx1; x += 4) {
                int r = f.r(x, y), g = f.g(x, y), b = f.b(x, y);
                total++;
                int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
                if (mx <= 48 && mx - mn <= 14) dark++;
            }
        return total > 0 && dark >= total * 0.55;
    }

    /**
     * What the shop shows right now: button positions + each card's rarity and stock + the
     * scrollbar position. Two different rows can have buttons in the same places, so positions
     * alone can't tell whether a swipe moved the list.
     */
    public static String viewSig(Frame f, Box region) {
        Buttons b = findShopButtons(f, region);
        List<String> parts = new ArrayList<>();
        for (Box x : b.buy) parts.add((x.x0 / 8) + ":" + (x.y0 / 8) + ":B:" + cardRarity(f, x));
        for (Box x : b.sold) parts.add((x.x0 / 8) + ":" + (x.y0 / 8) + ":S:" + cardRarity(f, x));
        java.util.Collections.sort(parts);
        Box th = findScrollThumb(f, b.all());
        return parts + (th == null ? "" : "|thumb:" + th.y0 / 4);
    }

    /** A signature of which buttons are where (positions only). */
    public static String layoutSig(Buttons b) {
        List<Box> all = b.all();
        int[] k = new int[all.size()];
        for (int i = 0; i < k.length; i++) k[i] = (all.get(i).x0 / 8) * 10000 + all.get(i).y0 / 8;
        Arrays.sort(k);
        return Arrays.toString(k);
    }
}
