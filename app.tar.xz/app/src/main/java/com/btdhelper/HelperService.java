package com.btdhelper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.btdhelper.vision.Frame;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The Accessibility service: it is what lets the helper see the screen (screenshots) and tap
 * inside Roblox (gestures). It also shows the floating button + control panel over the game.
 */
public class HelperService extends AccessibilityService implements Device {

    static final String ROBLOX = "com.roblox.client";

    private WindowManager wm;
    private final Executor shotExec = Executors.newSingleThreadExecutor();
    private volatile boolean robloxFg;
    private volatile int lastW, lastH;
    private long lastShotAt;

    // overlay views
    private FrameLayout bubble;
    private WindowManager.LayoutParams bubbleLp;
    private WebView panel;
    private WindowManager.LayoutParams panelLp;
    private boolean panelOpen;
    private View calView;

    // ================================================================ lifecycle
    @Override
    protected void onServiceConnected() {
        Hub.init(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Hub.service = this;
        if (Hub.engine == null) Hub.engine = new Engine(Hub.cfg, this);
        Rect r = wm.getMaximumWindowMetrics().getBounds();
        lastW = r.width();
        lastH = r.height();
        showBubble();
        Log2.add("Helper is on. Open Roblox and tap the floating button.", "ok");
        Hub.main.postDelayed(this::tickBubble, 500);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();
        if (pkg.equals(getPackageName()) || pkg.equals("com.android.systemui")) return;   // our panel / shade
        robloxFg = pkg.equals(ROBLOX);
    }

    @Override
    public void onInterrupt() {}

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        shutdown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        shutdown();
        super.onDestroy();
    }

    private void shutdown() {
        if (Hub.engine != null) Hub.engine.stop();
        Hub.engine = null;
        Hub.service = null;
        removeView(bubble);
        removeView(panel);
        removeView(calView);
        bubble = null;
        panel = null;
        calView = null;
    }

    private void removeView(View v) {
        if (v != null && v.isAttachedToWindow()) {
            try { wm.removeView(v); } catch (Exception ignored) { }
        }
    }

    // ================================================================ Device: seeing
    @Override
    public Frame capture() {
        for (int attempt = 0; attempt < 4; attempt++) {
            // Android allows about 3 screenshots per second
            long wait = 340 - (System.currentTimeMillis() - lastShotAt);
            if (wait > 0) {
                try { Thread.sleep(wait); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); return null; }
            }
            lastShotAt = System.currentTimeMillis();
            final CountDownLatch done = new CountDownLatch(1);
            final AtomicReference<Frame> out = new AtomicReference<>();
            final AtomicBoolean tooSoon = new AtomicBoolean(false);
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExec, new TakeScreenshotCallback() {
                @Override
                public void onSuccess(ScreenshotResult res) {
                    try {
                        HardwareBuffer hb = res.getHardwareBuffer();
                        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, res.getColorSpace());
                        if (hw != null) {
                            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                            hw.recycle();
                            int w = sw.getWidth(), h = sw.getHeight();
                            int[] px = new int[w * h];
                            sw.getPixels(px, 0, w, 0, 0, w, h);
                            sw.recycle();
                            lastW = w;
                            lastH = h;
                            out.set(new Frame(w, h, px));
                        }
                        hb.close();
                    } catch (Exception ex) {
                        Log2.log("Screenshot error: " + ex);
                    } finally {
                        done.countDown();
                    }
                }

                @Override
                public void onFailure(int code) {
                    if (code == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) tooSoon.set(true);
                    done.countDown();
                }
            });
            try {
                if (!done.await(3, TimeUnit.SECONDS)) continue;
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return null;
            }
            if (out.get() != null) return out.get();
            if (!tooSoon.get()) break;
        }
        return null;
    }

    @Override public int width() { return lastW; }
    @Override public int height() { return lastH; }

    @Override
    public boolean robloxForeground() { return robloxFg; }

    // ================================================================ Device: touching
    private boolean gesture(Path path, long ms) {
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, Math.max(1, ms)))
                .build();
        final CountDownLatch done = new CountDownLatch(1);
        final AtomicBoolean ok = new AtomicBoolean(false);
        Hub.main.post(() -> {
            boolean sent = dispatchGesture(g, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) { ok.set(true); done.countDown(); }
                @Override public void onCancelled(GestureDescription d) { done.countDown(); }
            }, null);
            if (!sent) done.countDown();
        });
        try {
            done.await(ms + 2000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
        return ok.get();
    }

    @Override
    public void tap(int x, int y, long ms) {
        Path p = new Path();
        p.moveTo(x, y);
        if (!gesture(p, ms)) Log2.log("Tap was cancelled by Android (touching the screen at the same time?)");
    }

    @Override
    public void swipe(int x, int y1, int y2, long ms) {
        Path p = new Path();
        p.moveTo(x, y1);
        p.lineTo(x, y2);
        gesture(p, ms);
    }

    @Override
    public void back() { performGlobalAction(GLOBAL_ACTION_BACK); }

    @Override
    public void setControlsHidden(boolean hidden) {
        final CountDownLatch done = new CountDownLatch(1);
        Hub.main.post(() -> {
            if (bubble != null) bubble.setVisibility(hidden || panelOpen ? View.GONE : View.VISIBLE);
            if (panel != null) panel.setVisibility(hidden || !panelOpen ? View.GONE : View.VISIBLE);
            done.countDown();
        });
        try {
            done.await(500, TimeUnit.MILLISECONDS);
            if (hidden) Thread.sleep(40);     // let the window manager apply it before tapping
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void alert() {
        try {
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90);
            tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 350);
            Hub.main.postDelayed(tg::release, 600);
        } catch (Exception ignored) {
        }
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) v.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE));
        } catch (Exception ignored) {
        }
    }

    @Override
    public void saveDebug(Frame f, String name) {
        try {
            File dir = getExternalFilesDir("debug_shots");
            if (dir == null) return;
            Bitmap bm = Bitmap.createBitmap(f.px, f.w, f.h, Bitmap.Config.ARGB_8888);
            File out = new File(dir, name + "_" + System.currentTimeMillis() + ".png");
            try (FileOutputStream os = new FileOutputStream(out)) {
                bm.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            bm.recycle();
        } catch (Exception e) {
            Log2.log("Couldn't save debug picture: " + e);
        }
    }

    // ================================================================ floating button + panel
    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private WindowManager.LayoutParams overlayLp(int w, int h, boolean focusable) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                (focusable ? 0 : WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void showBubble() {
        bubble = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#6aa2ff"), Color.parseColor("#3a6cf0"), Color.parseColor("#7c4dff")});
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(3), Color.parseColor("#5c6789"));
        bubble.setBackground(bg);
        bubble.setElevation(dp(6));
        TextView t = new TextView(this);
        t.setText("↻");
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        t.setGravity(Gravity.CENTER);
        bubble.addView(t, new FrameLayout.LayoutParams(-1, -1));
        bubbleLp = overlayLp(dp(52), dp(52), false);
        bubbleLp.x = dp(8);
        bubbleLp.y = Math.max(dp(8), lastH / 2 - dp(26));
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); ox = bubbleLp.x; oy = bubbleLp.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                        if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            bubbleLp.x = Math.max(0, (int) (ox + dx));
                            bubbleLp.y = Math.max(0, (int) (oy + dy));
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) openPanel(true);
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleLp);
    }

    /** Ring colour = status (green running, orange shop check, blue waiting, grey stopped). */
    private void tickBubble() {
        if (bubble == null) return;
        Engine en = Hub.engine;
        String st = en != null && en.isRunning() ? en.status : "Stopped";
        int ring = st.equals("Running") ? Color.parseColor("#2fca6c")
                : st.equals("Checking shop") ? Color.parseColor("#f7a928")
                : st.equals("Stopped") ? Color.parseColor("#5c6789") : Color.parseColor("#4f8cff");
        ((GradientDrawable) bubble.getBackground()).setStroke(dp(3), ring);
        Hub.main.postDelayed(this::tickBubble, 500);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    public void openPanel(boolean open) {
        Hub.main.post(() -> {
            if (open) {
                if (panel == null) {
                    panel = new WebView(this);
                    panel.setBackgroundColor(Color.TRANSPARENT);
                    panel.getSettings().setJavaScriptEnabled(true);
                    panel.addJavascriptInterface(new Bridge(this, true), "BTD");
                    panel.loadUrl("file:///android_asset/panel.html?mode=overlay");
                    int w = Math.min(lastW - dp(16), dp(760));
                    int h = lastH - dp(16);
                    panelLp = overlayLp(w, h, false);
                    panelLp.x = (lastW - w) / 2;
                    panelLp.y = dp(8);
                    wm.addView(panel, panelLp);
                }
                panel.setVisibility(View.VISIBLE);
                if (bubble != null) bubble.setVisibility(View.GONE);
                panelOpen = true;
            } else {
                if (panel != null) panel.setVisibility(View.GONE);
                if (bubble != null) bubble.setVisibility(View.VISIBLE);
                panelOpen = false;
            }
        });
    }

    // ================================================================ calibration
    private static final String[] CAL_TEXT = {
            "Tap the SPAWNERS button (right side of the screen).\nThe shop will open.",
            "Now tap the shop's red X (top right of the shop).",
            "Last one: tap the middle of the shop's list of cards.\nThe shop will close."
    };
    private int calStep;
    private final float[][] calPts = new float[3][];

    public boolean isCalibrating() { return calView != null; }

    public void startCalibration() {
        Hub.main.post(() -> {
            if (calView != null) { stopCalibration("Calibrate: cancelled."); return; }
            openPanel(false);
            calStep = 0;
            showCalStep();
        });
    }

    private void stopCalibration(String msg) {
        removeView(calView);
        calView = null;
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
        if (msg != null) Log2.log(msg);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void showCalStep() {
        removeView(calView);
        if (bubble != null) bubble.setVisibility(View.GONE);
        FrameLayout v = new FrameLayout(this);
        v.setBackgroundColor(Color.argb(90, 0, 0, 0));
        TextView t = new TextView(this);
        t.setText("Calibrate " + (calStep + 1) + "/3\n" + CAL_TEXT[calStep] + "\n\n(Press Back to cancel)");
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        GradientDrawable tb = new GradientDrawable();
        tb.setColor(Color.parseColor("#E61b2338"));
        tb.setCornerRadius(dp(14));
        t.setBackground(tb);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        tlp.topMargin = dp(calStep == 1 ? 140 : 24);
        v.addView(t, tlp);
        v.setFocusableInTouchMode(true);
        v.setOnKeyListener((vv, code, ev) -> {
            if (code == android.view.KeyEvent.KEYCODE_BACK) { stopCalibration("Calibrate: cancelled."); return true; }
            return false;
        });
        v.setOnTouchListener((vv, e) -> {
            if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
            float fx = e.getRawX() / Math.max(1, lastW), fy = e.getRawY() / Math.max(1, lastH);
            calPts[calStep] = new float[]{fx, fy};
            Log2.log(String.format(java.util.Locale.ROOT, "  saved point %d = %.4f, %.4f", calStep + 1, fx, fy));
            final int x = (int) e.getRawX(), y = (int) e.getRawY();
            final int step = calStep;
            removeView(calView);
            calView = null;
            new Thread(() -> {
                if (step == 0) {                 // open the shop for the next steps
                    tap(x, y, 80);
                    sleepQuiet(1500);
                } else if (step == 2) {          // close the shop again
                    float[] c = calPts[1];
                    tap(Math.round(c[0] * lastW), Math.round(c[1] * lastH), 80);
                }
                Hub.main.post(() -> {
                    if (step < 2) {
                        calStep = step + 1;
                        showCalStep();
                    } else {
                        Config cfg = Hub.cfg;
                        cfg.spawnersButton = calPts[0];
                        cfg.shopCloseButton = calPts[1];
                        cfg.shopListPoint = calPts[2];
                        cfg.save();
                        stopCalibration("Calibrate: done, positions saved.");
                    }
                });
            }).start();
            return true;
        });
        calView = v;
        WindowManager.LayoutParams lp = overlayLp(-1, -1, true);
        wm.addView(v, lp);
        v.requestFocus();
    }

    private static void sleepQuiet(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }
}
