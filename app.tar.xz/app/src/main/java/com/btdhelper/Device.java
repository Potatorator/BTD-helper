package com.btdhelper;

import com.btdhelper.vision.Frame;

/** What the automation needs from the phone. The Accessibility service implements this. */
public interface Device {
    /** A screenshot of the whole screen, or null if it failed. */
    Frame capture();
    int width();
    int height();
    /** Touch the screen at (x, y) for ms milliseconds. Blocks until done. */
    void tap(int x, int y, long ms);
    /** Drag a finger from (x, y1) to (x, y2) over ms milliseconds. Blocks until done. */
    void swipe(int x, int y1, int y2, long ms);
    /** The phone's Back action (closes Roblox's purchase popup). */
    void back();
    /** True if Roblox is the app on screen. */
    boolean robloxForeground();
    /** Hide/show the floating controls so taps can't land on them. */
    void setControlsHidden(boolean hidden);
    /** Sound + vibration when a wanted spawner is in stock. */
    void alert();
    /** Save a debug picture. */
    void saveDebug(Frame f, String name);
}
